---
name: pdf-book-generation
description: "Generate well-formatted PDF books from markdown chapters — typography, ASCII art, TOC, book layout."
version: 1.0.0
metadata:
  hermes:
    tags: [PDF, ebook, book, markdown, typography, fpdf2, publishing]
    related_skills: [ascii-art, ocr-and-documents, nano-pdf]
---

# PDF Book Generation

Turn a collection of markdown chapter files into a professionally-formatted PDF book with typography, ASCII art illustrations, table of contents, and proper book layout.

## When to use

- User has multiple markdown chapter files and wants a printable/publishable PDF
- User says "make this into a book", "create a PDF", "format this as an ebook"
- User wants illustrations (ASCII art) embedded in a formatted document
- Converting a novel, report, documentation set, or multi-chapter work into a single polished PDF

## Environment dependencies

```bash
pip install fpdf2 pyfiglet --target=/path/to/libs --no-deps
```

Required fonts (must be available as .ttf files):
- A serif/sans body font (DejaVu Sans works universally)
- A monospace font for ASCII art (DejaVu Sans Mono)
- Bold variants of both

Standard locations: `/usr/share/fonts/truetype/dejavu/`

## Book design defaults

These produce a clean, readable paperback-like result on A5:

| Parameter | Value | Notes |
|-----------|-------|-------|
| Page size | A5 (148×210 mm) | Book-like proportions |
| Margins | 16 mm all sides | Comfortable for reading |
| Body font | Serif, 7.5pt | DejaVu Sans at this size reads cleanly |
| Mono font | Mono, 4–6pt | Smaller for ASCII art that fits page width |
| Title font | Mono Bold, 5–6pt | pyfiglet `small` font for chapter banners |
| Line height | ~4.2 mm for body text | Good readability at 7.5pt |
| Header | 7pt gray, book title + page number | Running header on content pages (hidden on title/TOC/chapter-start pages) |
| Footer | Centered page number, 6pt | Subtle, on every page |

## Build script structure

See `references/build_pdf_template.py` for the complete working template. The script follows this pattern:

1. **Font registration** — register serif + mono + bold variants via `add_font()`
2. **Title page** — pyfiglet banner for the book title + a decorative ASCII illustration + subtitle/date line
3. **Table of contents** — list all chapters grouped by act/part, with decorative rules between sections
4. **Chapter pages** — each chapter starts on a new page: pyfiglet chapter number banner → title → decorative rule → ASCII illustration (centered, ~4pt mono) → rule → prose text
5. **Prose rendering** — walk the markdown body line by line, handling:
   - Empty lines → `ln(2)` vertical space
   - `---` → thin decorative line (30–70% of page width, centered)
   - `***` → scene divider (`─────── ◆ ───────` in mono font)
   - `> blockquote` → italic, indented 6mm, smaller font (7pt), muted color
   - Regular text → justified `multi_cell()` with 4.2mm line height
6. **Colophon** — final page with closing art/quote

## ASCII art in PDFs

Key technique: render ASCII art at very small mono font sizes so complex art fits within the page width.

```python
# For chapter-opening illustrations (detailed art):
pdf.set_font('Mono', '', 4)          # ~50 chars fit in A5 body width
pdf.set_text_color(100, 80, 50)      # Muted warm tone
for line in art.split('\n'):
    pdf.cell(0, 2.5, line, align='C', new_x="LMARGIN", new_y="NEXT")

# For pyfiglet banners (chapter numbers/titles):
banner = pyfiglet.figlet_format("Chapter 1", font="small")
pdf.set_font('Mono', 'B', 5)         # Slightly larger for banners
for line in banner.split('\n'):
    pdf.cell(0, 3.5, line, align='C', new_x="LMARGIN", new_y="NEXT")
```

**Crucial**: Only use characters the mono font actually has. DejaVu Sans Mono lacks many emoji (🐐🐎🧑☀️⚖️♜★ॐ⊚). Test or pre-filter art. Replace emoji with ASCII equivalents: `(())` for horses, `o` for person heads, `*` for stars, `@` for sun symbols, etc.

## Pitfalls

1. **Emoji/unicode in ASCII art breaks PDF rendering** — DejaVu Sans Mono has limited glyph coverage. The PDF will generate but those characters will be blank. Always use pure ASCII or common box-drawing characters (╔╗╚╝║═ etc.).

2. **fpdf2 deprecation**: The `uni=True` parameter on `add_font()` is deprecated since v2.5.1. Just omit it — TTF fonts handle Unicode automatically.

3. **fpdf2 auto page break can split art mid-illustration** — always `add_page()` before chapter-start art to avoid orphaned art fragments at page bottoms.

4. **`multi_cell()` doesn't honor inline bold/italic** — fpdf2 has limited inline styling. For bold spans in prose, either pre-process the markdown or accept that all body text will be uniform. The template handles block-level formatting (headers, blockquotes, dividers) but not inline `**bold**` or `*italic*`.

5. **pip install timeout in containers** — use `--no-deps` flag to avoid dependency resolution overhead. fpdf2 and pyfiglet have minimal deps.

## Related skills

- `ascii-art` — generate the illustrations used in chapter openers
- `nano-pdf` — edit/annotate existing PDFs after generation
- `ocr-and-documents` — extract text back from the generated PDF if needed
