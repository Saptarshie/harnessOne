#!/usr/bin/env python3
"""
PDF Book Generator — reusable template.
Drop this into your project, configure CHAPTERS_DIR and the art dict, then run.

Requires: fpdf2, pyfiglet  (pip install fpdf2 pyfiglet --no-deps)
"""

import os, sys, re
from fpdf import FPDF
import pyfiglet

# ── Paths ──────────────────────────────────────────────────
CHAPTERS_DIR = "./chapters"          # Directory containing .md chapter files
OUTPUT_PDF  = "./book.pdf"           # Output path
FONT_SERIF  = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
FONT_BOLD   = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
FONT_MONO   = "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf"
FONT_MONO_B = "/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf"

# ── Book dimensions (A5) ───────────────────────────────────
PAGE_W, PAGE_H = 148, 210
MARGIN = 16
BODY_W = PAGE_W - 2 * MARGIN

SCENE_DIVIDER = "       ─────── ◆ ───────"

# ── Custom PDF class ───────────────────────────────────────
class BookPDF(FPDF):
    def __init__(self):
        super().__init__('P', 'mm', (PAGE_W, PAGE_H))
        self.set_auto_page_break(True, MARGIN)
        self.add_font('Serif', '', FONT_SERIF)
        self.add_font('Serif', 'B', FONT_BOLD)
        self.add_font('Mono', '', FONT_MONO)
        self.add_font('Mono', 'B', FONT_MONO_B)
        self.page_has_header = True

    def header(self):
        if not self.page_has_header:
            return
        self.set_font('Serif', '', 7)
        self.set_text_color(130, 130, 130)
        self.cell(0, 4, 'Book Title', align='L')
        self.cell(0, 4, str(self.page_no()), align='R', new_x="LMARGIN", new_y="NEXT")
        self.set_draw_color(180, 180, 180)
        self.line(self.l_margin, self.get_y()+1, PAGE_W-self.r_margin, self.get_y()+1)
        self.ln(5)

    def footer(self):
        self.set_y(-MARGIN + 8)
        self.set_font('Serif', '', 6)
        self.set_text_color(160, 160, 160)
        self.cell(0, 4, str(self.page_no()), align='C')

    def title_page(self, title_text, cover_art, subtitle=""):
        """Render a title page with pyfiglet banner and cover art."""
        self.add_page()
        self.page_has_header = False
        self.set_font('Mono', 'B', 5)
        self.set_text_color(60, 40, 20)
        banner = pyfiglet.figlet_format(title_text, font="small")
        for line in banner.split('\n'):
            if line.strip():
                self.cell(0, 3.2, line, align='C', new_x="LMARGIN", new_y="NEXT")
        self.ln(6)
        if cover_art:
            self.set_font('Mono', '', 4)
            self.set_text_color(80, 60, 40)
            for line in cover_art.split('\n'):
                self.cell(0, 2.5, line, align='C', new_x="LMARGIN", new_y="NEXT")
        self.ln(8)
        if subtitle:
            self.set_font('Serif', 'B', 11)
            self.set_text_color(60, 40, 20)
            self.cell(0, 6, subtitle, align='C', new_x="LMARGIN", new_y="NEXT")

    def table_of_contents(self, chapters, acts=None):
        """Render TOC. chapters: list of (num, title). acts: dict of {num: act_name}."""
        self.add_page()
        self.page_has_header = False
        self.set_font('Serif', 'B', 14)
        self.set_text_color(60, 40, 20)
        self.cell(0, 8, 'Contents', align='C', new_x="LMARGIN", new_y="NEXT")
        self.ln(8)
        for i, (num, title) in enumerate(chapters, 1):
            if acts and i in acts:
                self.ln(4)
                self.set_font('Serif', 'B', 8)
                self.set_text_color(100, 70, 40)
                self.cell(0, 5, acts[i], align='L', new_x="LMARGIN", new_y="NEXT")
                self.set_draw_color(180, 160, 120)
                self.line(self.l_margin, self.get_y()+1, PAGE_W-self.r_margin, self.get_y()+1)
                self.ln(5)
            self.set_font('Serif', '', 8)
            self.set_text_color(60, 40, 20)
            self.cell(16, 5, num, align='R')
            self.set_font('Serif', 'B', 8)
            self.cell(0, 5, f'  {title}', align='L', new_x="LMARGIN", new_y="NEXT")
            self.ln(2)

    def start_chapter(self, num, title, art, subtitle=""):
        """Start a new chapter page with banner, title, art, and rules."""
        self.add_page()
        self.page_has_header = False
        # Chapter number banner
        self.set_font('Mono', 'B', 6)
        self.set_text_color(60, 40, 20)
        num_text = pyfiglet.figlet_format(f"Chapter {num}", font="small")
        for line in num_text.split('\n'):
            if line.strip():
                self.cell(0, 3.8, line, align='C', new_x="LMARGIN", new_y="NEXT")
        self.ln(2)
        # Title
        self.set_font('Serif', 'B', 11)
        self.cell(0, 6, title, align='C', new_x="LMARGIN", new_y="NEXT")
        if subtitle:
            self.set_font('Serif', '', 7)
            self.set_text_color(120, 100, 80)
            self.cell(0, 4, subtitle, align='C', new_x="LMARGIN", new_y="NEXT")
        self.ln(4)
        # Decorative rule
        self.set_draw_color(160, 130, 90)
        self.set_line_width(0.3)
        y = self.get_y()
        self.line(self.l_margin+15, y, PAGE_W-self.r_margin-15, y)
        self.ln(4)
        # Illustration
        if art:
            self.set_font('Mono', '', 4)
            self.set_text_color(100, 80, 50)
            for line in art.split('\n'):
                if line.strip():
                    self.cell(0, 2.5, line, align='C', new_x="LMARGIN", new_y="NEXT")
            self.ln(4)
            y2 = self.get_y()
            self.line(self.l_margin+15, y2, PAGE_W-self.r_margin-15, y2)
            self.ln(5)
        self.page_has_header = True

    def render_prose(self, text, body_font_size=7.5):
        """Render body text with scene dividers and blockquotes."""
        self.set_text_color(40, 30, 20)
        self.set_font('Serif', '', body_font_size)
        for line in text.split('\n'):
            if not line.strip():
                self.ln(2)
                continue
            if line.strip().startswith('---') and len(line.strip()) <= 5:
                self.ln(2)
                self.set_draw_color(180, 160, 130)
                self.set_line_width(0.2)
                y = self.get_y()
                cx = self.l_margin + BODY_W * 0.3
                self.line(cx, y, cx + BODY_W * 0.4, y)
                self.ln(3)
                continue
            if line.strip() in ('***', '* * *'):
                self.ln(3)
                self.set_font('Mono', '', 6)
                self.set_text_color(150, 130, 100)
                self.cell(0, 4, SCENE_DIVIDER, align='C', new_x="LMARGIN", new_y="NEXT")
                self.set_font('Serif', '', body_font_size)
                self.set_text_color(40, 30, 20)
                self.ln(3)
                continue
            if line.strip().startswith('>'):
                self.set_font('Serif', '', 7)
                self.set_text_color(100, 80, 60)
                content = line.strip().lstrip('>').strip()
                self.set_x(self.l_margin + 6)
                self.multi_cell(BODY_W - 12, 4.2, content, align='L')
                self.set_font('Serif', '', body_font_size)
                self.set_text_color(40, 30, 20)
                self.ln(2)
                continue
            self.set_x(self.l_margin)
            self.multi_cell(BODY_W, 4.2, line, align='J')


# ── Helper ─────────────────────────────────────────────────
def parse_chapter_text(filepath):
    """Extract title, subtitle, body from a markdown chapter file."""
    with open(filepath) as f:
        content = f.read()
    lines = content.split('\n')
    title = subtitle = ""
    body_lines = []
    in_header = True
    for line in lines:
        if in_header and line.startswith('# '):
            title = re.sub(r'^Chapter\s+\w+[\s:—–-]+', '',
                           line.lstrip('# ').strip(), flags=re.IGNORECASE)
            continue
        if in_header and line.startswith('>'):
            subtitle = line.strip().lstrip('>').strip().strip('*').strip()
            continue
        if in_header and line.startswith('---'):
            in_header = False
            continue
        if not in_header:
            body_lines.append(line)
    return title, subtitle, '\n'.join(body_lines)


# ── Main entry point — customize this section ──────────────
def main():
    pdf = BookPDF()

    # ── Title page ──
    COVER_ART = r"""   ... your ASCII cover art here ...   """
    pdf.title_page("BOOK TITLE", COVER_ART, "A Novel · 2026")

    # ── TOC ──
    chapter_info = [
        ("ONE",   "Chapter Title 1"),
        ("TWO",   "Chapter Title 2"),
        # ... add all chapters
    ]
    acts = {1: "Act I — Name", 4: "Act II — Name"}
    pdf.table_of_contents(chapter_info, acts)

    # ── Chapter art ──
    chapter_art = {
        1: r"""  ... ASCII art for chapter 1 ...  """,
        2: r"""  ... ASCII art for chapter 2 ...  """,
        # ... add art for each chapter
    }

    # ── Render chapters ──
    for num, fname in enumerate(sorted(os.listdir(CHAPTERS_DIR)), 1):
        if not fname.endswith('.md'):
            continue
        title, subtitle, body = parse_chapter_text(os.path.join(CHAPTERS_DIR, fname))
        print(f"  Chapter {num}: {title}")
        pdf.start_chapter(num, title, chapter_art.get(num, ""), subtitle)
        pdf.render_prose(body)

    # ── Save ──
    pdf.output(OUTPUT_PDF)
    print(f"\nDone: {OUTPUT_PDF}  ({pdf.page_no()} pages, {os.path.getsize(OUTPUT_PDF)//1024} KB)")


if __name__ == '__main__':
    main()
