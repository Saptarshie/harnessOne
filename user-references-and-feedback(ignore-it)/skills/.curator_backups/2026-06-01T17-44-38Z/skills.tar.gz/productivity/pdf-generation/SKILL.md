---
name: pdf-generation
description: "Generate formatted PDF documents: markdown-to-PDF books, reports, with optional ASCII art / illustrations."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos]
metadata:
  hermes:
    tags: [PDF, Documents, Books, Formatting, fpdf2, ASCII]
    related_skills: [ascii-art]
---

# PDF Generation

Generate well-formatted PDF documents from markdown, plain text, or programmatic content. Covers book-style layouts, reports, and mixed-format documents with embedded ASCII art.

## When to Use

- Converting markdown chapters/documents into a formatted PDF book
- Creating reports with title pages, tables of contents, and chapter formatting
- Embedding ASCII art (pyfiglet, custom box-drawing) into PDF pages
- Any task requiring programmatic PDF layout with custom fonts and typography

## Prerequisites

```bash
pip install fpdf2 pyfiglet --target=/some/writable/path
```

- **fpdf2**: Lightweight PDF generation library (no system deps needed)
- **pyfiglet**: ASCII art banner generation for titles and headings
- **Monospace font**: Required for ASCII art rendering (DejaVu Sans Mono is universally available on Linux)

## Quick Start

Minimal book generator pattern:

```python
from fpdf import FPDF

pdf = FPDF(orientation='P', unit='mm', format=(148, 210))  # A5
pdf.add_font('Mono', '', '/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf')
pdf.add_font('Serif', '', '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf')
pdf.set_auto_page_break(True, 16)

pdf.add_page()
pdf.set_font('Mono', '', 4)
# Render ASCII art line by line
for line in ascii_art.split('\n'):
    pdf.cell(0, 2.5, line, align='C', new_x="LMARGIN", new_y="NEXT")

pdf.set_font('Serif', '', 7.5)
pdf.multi_cell(body_width, 4.2, prose_text, align='J')

pdf.output('output.pdf')
```

## Proven Book Layout (A5, 148x210mm)

### Dimensions

| Parameter | Value |
|-----------|-------|
| Page size | 148 x 210 mm (A5 — book-like) |
| Margins | 16 mm all around |
| Body font | DejaVu Sans, 8–8.5pt, justified |
| Mono font | DejaVu Sans Mono, 4pt (for ASCII art) |
| Line height | 4.8 mm (body), 2.5 mm (mono art) |
| Chapter title | 11pt bold, centered |

### Critical fpdf2 Gotchas

1. **Margins must be set explicitly.** `set_auto_page_break(True, 16)` sets only the *bottom* margin. Left/right margins default to 10mm. Always add:
   ```python
   self.set_left_margin(MARGIN)
   self.set_right_margin(MARGIN)
   ```

2. **`cell(w=0)` clips, `multi_cell()` wraps.** `cell(0, h, text)` extends to the right margin but DOES NOT auto-wrap — long text runs off the page. Use `multi_cell(w, h, text)` for any text that might exceed the body width. This is the #1 cause of text-overflow bugs in fpdf2.

3. **Links need destinations before use.** `add_link()` creates a target; `set_link(link, page=N)` must be called before `cell(link=link)`. But `set_link()` accepts FUTURE page numbers — you can pre-set destinations to pages that don't exist yet. This enables TOC-before-chapters builds.

### Chapter Structure

Each chapter page has:
1. ASCII art chapter number (pyfiglet, `small` font, mono 6pt)
2. Chapter title (serif bold, 11pt)
3. Optional subtitle/epigraph (serif italic, 7pt, muted color)
4. Decorative rule (`set_draw_color` + `line`)
5. ASCII art illustration (mono 4pt, centered, muted color)
6. Second decorative rule
7. Body prose (serif 7.5pt, justified)

### Page Header/Footer

```python
def header(self):
    self.set_font('Serif', '', 7)
    self.set_text_color(130, 130, 130)
    self.cell(0, 4, 'Book Title', align='L')
    self.cell(0, 4, str(self.page_no()), align='R')

def footer(self):
    self.set_y(-16 + 8)
    self.set_font('Serif', '', 6)
    self.cell(0, 4, str(self.page_no()), align='C')
```

### Scene Breaks

Replace `***` or `---` in source text with a centered decorative divider:

```
─────── ◆ ───────
```

Rendered in mono 6pt, muted color.

## Emoji / Unicode Pitfall

DejaVu Sans Mono cannot render emoji characters (🐐, ★, ☀, ॐ, etc.). Replace them with ASCII equivalents in all art:

| Avoid | Use Instead |
|-------|-------------|
| Emoji animals (🐐, 🐎) | Text: `goat`, `(())` for horse |
| ★ | `*` |
| ☀ | `sunburst` or `*` |
| ॐ | `Om` |
| ♜ | `R` |
| ⚖ | `[*]` |
| ⊚ | `@` |

**Detection:** On PDF generation, fpdf2 will log `Font X is missing the following glyphs: …`. Treat these as errors to fix before final render.

## Markdown Parsing for PDF

Minimal markdown-to-PDF parsing (no external markdown library needed):

| Markdown | PDF Rendering |
|----------|---------------|
| `# Title` | Chapter title (extracted, removed from body) |
| `> quote` | Italic blockquote, indented, smaller font, muted color |
| `---` (HR) | Decorative centered rule |
| `***` | Scene break divider |
| `**bold**` | Bold span (fpdf2 rich text or separate cells) |
| Blank line | `pdf.ln(2)` paragraph break |
| Regular paragraph | `multi_cell(body_width, line_height, text, align='J')` |

## Title Page

Use pyfiglet for the book title banner:

```python
import pyfiglet
banner = pyfiglet.figlet_format("THE TITLE", font="small")
# Render each line centered in mono bold, ~5pt
```

Follow with the cover ASCII illustration, author line, and date in serif.

## Table of Contents

Group chapters by act/section. Use serif 8pt, with decorative rules between sections:

```python
acts = {1: "Act I — Name", 3: "Act II — Name", ...}
for i, (num, title) in enumerate(chapters):
    if i+1 in acts:
        pdf.set_font('Serif', 'B', 8)
        pdf.cell(0, 5, acts[i+1])
        pdf.line(...)  # decorative rule
    pdf.set_font('Serif', '', 8)
    pdf.cell(16, 5, f'{num}')
    pdf.cell(0, 5, f'  {title}')
```

## Verification

After generation, validate the PDF:

```bash
file output.pdf                    # Should say: PDF document, version 1.3
python3 -c "
with open('output.pdf', 'rb') as f:
    h = f.read(100)
    print('Header:', h[:50])
    f.seek(-50, 2)
    print('Trailer:', f.read(50))
"                                  # Should end with %%EOF
```

## Bundled Resources

- `references/book-generation-reference.md` — Production reference: font sizes, color palette, art sizing, scene-break patterns used in the 61-page "Firman of Monsoons" novel build.
- `templates/book-generator.py` — Runable scaffold: subclass BookPDF with title page, chapter starts, prose rendering, and markdown parsing. Copy and customize the CHAPTER_ART dict and COVER_ART.
